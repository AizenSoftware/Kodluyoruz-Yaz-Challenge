export default easy;
 function easy(){
    const hız = 60;
    const yol = 240;


    return console.log(`${yol/hız} saatte alır`);
}