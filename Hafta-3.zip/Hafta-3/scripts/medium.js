export default upperCaseKelime;
function upperCaseKelime(string){
    console.log(`Orijinal Kelime: ${string}`);
    console.log(`Büyük Harfli Kelime: ${string.toUpperCase()}`);
}