import easy from "./scripts/easy.js"; 
import medium from "./scripts/medium.js";
import hard from "./scripts/hard.js";

// Easy
  easy();
